



gender_list_fxn <- function(short=F){
  if(short) return(gender_list_short) else return(gender_list)
}